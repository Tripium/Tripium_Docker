<?php
extract( $atts );
echo urldecode(base64_decode($code));
