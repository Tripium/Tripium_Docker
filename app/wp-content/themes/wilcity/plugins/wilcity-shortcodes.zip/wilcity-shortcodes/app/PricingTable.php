<?php
namespace WILCITY_SC;

class PricingTable {
	public static function baztag_func($atts) {
		return "dad";
	}
}