<?php
return [
  'TYPE'         => 'TESTIMONIAL',
  '_id'          => '',
  'icon'         => 'la la-quote-right',
  'testimonials' => [],
  'autoplay'     => '',
  'extra_class'  => ''
];
