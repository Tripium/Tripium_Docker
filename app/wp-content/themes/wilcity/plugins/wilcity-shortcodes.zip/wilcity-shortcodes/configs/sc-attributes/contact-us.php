<?php
return [
  'TYPE'                   => 'ContactUs',
  '_id'                    => '',
  'contact_info_heading'   => '',
  'contact_form_heading'   => '',
  'contact_form_7'         => '',
  'contact_form_shortcode' => '',
  'contact_info'           => [],
  'extra_class'            => ''
];
