<?php
return [
  'TYPE'        => 'TEAM_INTRO_SLIDER',
  '_id'         => '',
  'get_by'      => 'administrator',
  'members'     => [],
  'extra_class' => ''
];
