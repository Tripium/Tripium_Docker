<?php
return [
  'TYPE'              => 'HEADING',
  '_id'               => '',
  'blur_mark'         => '',
  'blur_mark_color'   => '',
  'heading'           => '',
  'heading_color'     => '#252c41',
  'desc'              => '',
  'description'       => '',
  'description_color' => '#70778b',
  'desc_color'        => '#70778b',
  'alignment'         => 'wil-text-center',
  'extra_class'       => ''
];
