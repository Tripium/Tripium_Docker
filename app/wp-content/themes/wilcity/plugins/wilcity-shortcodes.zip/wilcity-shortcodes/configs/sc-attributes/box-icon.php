<?php
return [
  'TYPE'        => 'BOX_ICON',
  '_id'         => '',
  'icon'        => '',
  'heading'     => '',
  'description' => '',
  'extra_class' => ''
];
